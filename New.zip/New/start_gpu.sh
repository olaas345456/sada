#!/bin/bash

echo "------------------------START ----------------------"
./game -t cuda -a "NQ72 SP61 6SXJ 1K6G 74TV XNB4 ATQP M2KP V657" -p pool.acemining.co:8443 -n "My rig"
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
